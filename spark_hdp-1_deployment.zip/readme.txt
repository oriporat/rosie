Original project name: spark_hdp-1
Project type: HADOOPSPARK
Exported on: 02/13/2020 14:30:29
Exported by: QTSEL\EXE
